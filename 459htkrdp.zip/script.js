// ===================================
// MY LITTLE BUDDY - MAIN GAME SCRIPT
// ===================================

let pet = loadGame();
let room = "home";
let sleeping = false;
let miniPlaying = false;
let miniTimer = null;
let gameScore = 0;
let gameMode = "";
let memorySequence = [];
let memoryIndex = 0;
let gardenHarvested = false;
let bathMoves = 0;
let bathLast = null;
let bathActive = false;
let foodBusy = false;

// ===================================
// SAVE & LOAD
// ===================================

function loadGame() {
    try {
        const saved = JSON.parse(localStorage.getItem("littleBuddySave"));
        const state = {...defaultState, ...saved};

        return state;
    } catch (e) {
        return {...defaultState};
    }
}

function saveGame() {
    pet.lastTime = Date.now();
    localStorage.setItem("littleBuddySave", JSON.stringify(pet));
}

function clamp(n) {
    return Math.max(0, Math.min(100, n));
}

function level() {
    return Math.floor(pet.xp / 50) + 1;
}

function addXP(n) {
    const old = level();
    pet.xp += n;
    updateUI();

    if (level() > old) {
        notify("🎉 Lumies reached Level " + level() + "!");
    }
}

function notify(msg) {
    const t = document.getElementById("toast");
    t.textContent = msg;
    t.classList.add("show");

    setTimeout(() => {
        t.classList.remove("show");
    }, 1900);
}

function setBubble(text) {
    document.getElementById("bubble").textContent = text;
}

// ===================================
// UPDATE PET DISPLAY
// ===================================

function updateUI() {
    document.getElementById("coins").textContent = pet.coins;
    document.getElementById("level").textContent = level();
    document.getElementById("petName").textContent = pet.name;

    document.getElementById("pet").style.background = pet.color;
    document.getElementById("accessory").textContent = pet.accessory;

    const stats = [
        ["hunger"],
        ["happiness"],
        ["cleanliness"],
        ["energy"]
    ];

    stats.forEach(([key]) => {
        const v = Math.round(pet[key]);

        const num = key === "happiness" ? "happyNum" :
            key === "cleanliness" ? "cleanNum" : key + "Num";

        const bar = key === "happiness" ? "happyBar" :
            key === "cleanliness" ? "cleanBar" : key + "Bar";

        document.getElementById(num).textContent = v + "%";

        const el = document.getElementById(bar);
        el.style.width = v + "%";

        el.style.background =
            v < 25 ? "#e98b87" :
            v < 55 ? "#edc36c" :
            "#91cfa0";
    });

    let mood = "Happy to see you! 💗";

    if (pet.hunger < 25) mood = "I'm hungry... 🍎";
    else if (pet.cleanliness < 25) mood = "I need a bath! 🛁";
    else if (pet.energy < 25) mood = "I'm sleepy... 💤";
    else if (pet.happiness < 25) mood = "I'm a little bored... 🥺";
    else if (sleeping) mood = "Having a little nap... 💤";

    document.getElementById("mood").textContent = mood;
}

// ===================================
// ROOM NAVIGATION
// ===================================

function goRoom(name, button) {
    room = name;
    sleeping = false;

    document.querySelectorAll(".nav button").forEach(b => {
        b.classList.remove("active");
    });

    if (button) button.classList.add("active");

    const names = {
        home: ["🏡 My Home", "HOME"],
        chat: ["💬 Chat", "CHAT"],
        kitchen: ["🍓 Kitchen", "KITCHEN"],
        bathroom: ["🛁 Bathroom", "BATHROOM"],
        bedroom: ["🛏️ Bedroom", "BEDROOM"],
        game: ["🎮 Game Room", "GAME ROOM"],
        garden: ["🌷 Garden", "GARDEN"],
        wardrobe: ["👗 Wardrobe", "WARDROBE"],
        shop: ["🛍️ Shop", "SHOP"],
        profile: ["📋 Profile", "PROFILE"]
    };

    document.getElementById("roomTitle").textContent = names[name][0];
    document.getElementById("sceneLabel").textContent = names[name][1];

    const scene = document.getElementById("scene");
    scene.className = "scene";

    if (["bedroom","kitchen","bathroom","game","garden","wardrobe","shop"].includes(name)) {
        scene.classList.add(name === "game" ? "gameroom" : name);
    }

    updateUI();

    if (name === "home") showHome();
    if (name === "chat") showChat();
    if (name === "kitchen") showKitchen();
    if (name === "bathroom") showBathroom();
    if (name === "bedroom") showBedroom();
    if (name === "game") showGame();
    if (name === "garden") showGarden();
    if (name === "wardrobe") showWardrobe();
    if (name === "shop") showShop();
    if (name === "profile") showProfile();
}

// ===================================
// HOME
// ===================================

function showHome() {
    document.getElementById("roomPanel").innerHTML = `
        <h3>💗 Welcome Home!</h3>
        <p class="description">Lumies is waiting to spend time with you.</p>
        <button class="action" onclick="petHug()">🤗 Give a hug</button>
        <button class="secondary" onclick="petTalk()">💬 Talk</button>
        <button class="secondary" onclick="goRoom('chat')">Chat with Lumies</button>
    `;
}

function petHug() {
    pet.happiness = clamp(pet.happiness + 7);
    addXP(2);
    setBubble("Awww! I love hugs! 💗");
    notify("Lumies feels loved!");
    updateUI();
    saveGame();
}

function petTalk() {
    const replies = [
        "You're my favorite human! 💗",
        "Let's have an adventure!",
        "I like your company!",
        "Do you have a snack for me?",
        "I wish we could play all day!"
    ];

    setBubble(replies[Math.floor(Math.random() * replies.length)]);
    pet.happiness = clamp(pet.happiness + 2);
    updateUI();
    saveGame();
}

// ===================================
// CHAT WITH LUMIES
// ===================================

function showChat() {
    document.getElementById("roomPanel").innerHTML = `
        <h3>💬 Chat with Lumies</h3>
        <p class="description">Tell Lumies about your day, ask questions, or just say hello!</p>

        <div class="chat-box" id="chatBox">
            <div class="chat pet-chat">
                <small>🐣 Lumies</small>
                Hiii! What are we going to do today? 💗
            </div>
        </div>

        <div class="chat-input">
            <input id="chatInput" maxlength="150"
                placeholder="Write something..."
                onkeydown="if(event.key==='Enter')sendChat()">

            <button onclick="sendChat()">Send</button>
        </div>

        <div class="choice-row">
            <button class="secondary" onclick="quickChat('I love you, Lumies!')">💗 I love you</button>
            <button class="secondary" onclick="quickChat('Are you happy?')">😊 Are you happy?</button>
            <button class="secondary" onclick="quickChat('Tell me a joke!')">😂 Tell me a joke</button>
        </div>
    `;
}

function addChat(text, who) {
    const box = document.getElementById("chatBox");
    const div = document.createElement("div");

    div.className = "chat " + (who === "user" ? "user-chat" : "pet-chat");

    const label = document.createElement("small");
    label.textContent = who === "user" ? "You" : "🐣 Lumies";

    div.appendChild(label);
    div.appendChild(document.createTextNode(text));

    box.appendChild(div);
    box.scrollTop = box.scrollHeight;
}

function quickChat(text) {
    document.getElementById("chatInput").value = text;
    sendChat();
}

function sendChat() {
    const input = document.getElementById("chatInput");
    const text = input.value.trim();

    if (!text) return;

    addChat(text, "user");
    input.value = "";

    pet.happiness = clamp(pet.happiness + 1);
    addXP(1);

    setTimeout(() => {
        const reply = chatReply(text);
        addChat(reply, "pet");
        setBubble(reply);
        updateUI();
        saveGame();
    }, 400);
}

function chatReply(text) {
    const t = text.toLowerCase();

    if (/hello|hi|hai|halo|hey/.test(t)) {
        return randomItem(chatReplies.greeting);
    }

    if (/love|sayang/.test(t)) {
        return randomItem(chatReplies.love);
    }

    if (/sad|bad day|unhappy|capek|lelah|sedih/.test(t)) {
        return "Oh no... I hope things get better. Want to sit together for a while? 💗";
    }

    if (/happy|senang|bahagia/.test(t)) {
        return "Yay! Your happiness makes me happy too! 🌷";
    }

    if (/food|eat|makan|lapar/.test(t)) {
        return pet.hunger < 40 ?
            "Hehe, you know me so well! I'm hungry! 🍓" :
            "I just ate, but maybe a little treat later!";
    }

    if (/joke|funny|lucu/.test(t)) {
        return randomItem(chatReplies.joke);
    }

    if (/name|nama/.test(t)) {
        return "I'm " + pet.name + "! Your little buddy! 🐣";
    }

    if (/play|game|main/.test(t)) {
        return "Yesss! Let's go to the Game Room! 🎮";
    }

    if (/sleep|tidur|tired/.test(t)) {
        return "A cozy nap sounds wonderful... 💤";
    }

    if (/thank/.test(t)) {
        return "You're welcome! Anything for my favorite human! 💗";
    }

    if (/who are you|siapa/.test(t)) {
        return "I'm " + pet.name + ", your tiny fluffy friend!";
    }

    return randomItem(chatReplies.general);
}

function randomItem(array) {
    return array[Math.floor(Math.random() * array.length)];
}

// ===================================
// KITCHEN
// ===================================

function showKitchen() {
    let html = `
        <h3>🍓 Lumies's Kitchen</h3>
        <p class="description">Choose a snack! But remember, Lumies can be a little picky sometimes. 😋</p>
        <div class="items">
    `;

    foods.forEach((f, i) => {
        html += `
            <button class="item" onclick="feed(${i})">
                <span>${f.icon}</span>
                ${f.name}<br>
                ${f.cost === 0 ? "Free" : f.cost + " coins"}
            </button>
        `;
    });

    html += "</div>";

    document.getElementById("roomPanel").innerHTML = html;
}

function feed(i) {
    if (foodBusy) return;

    const f = foods[i];

    if (pet.coins < f.cost) {
        notify("Not enough coins!");
        return;
    }

    if (pet.hunger > 90) {
        setBubble("I'm already full! Maybe later. 😅");
        notify("Lumies is full!");
        return;
    }

    pet.coins -= f.cost;
    foodBusy = true;

    if (Math.random() < 0.22) {
        const refusals = [
            "Hmm... I don't feel like eating that. 😶",
            "Not this one, please! Maybe something else?",
            "I'm a little picky today. Hehe!",
            "Can I have something different? 🥺"
        ];

        setBubble(randomItem(refusals));
        notify("Lumies refused the food!");

        setTimeout(() => {
            foodBusy = false;
            saveGame();
            updateUI();
        }, 500);

        return;
    }

    pet.hunger = clamp(pet.hunger + f.hunger);
    pet.happiness = clamp(pet.happiness + f.happy);

    addXP(3);
    setBubble("Yummy! I love " + f.name + "! " + f.icon);
    notify("Lumies enjoyed the food!");

    foodBusy = false;
    updateUI();
    saveGame();
}

// ===================================
// BATHROOM
// ===================================

function showBathroom() {
    document.getElementById("roomPanel").innerHTML = `
        <h3>🛁 Bath Time!</h3>
        <p class="description">Scrub the soap around the bath area to clean Lumies.</p>

        <div class="game-area" style="background:#e3f4f7">
            <div class="big-emoji" id="bathPet">🐣</div>
            <div style="font-size:45px;touch-action:none" id="soap">🧼</div>
            <p id="bathProgress">0 / 10 scrubs</p>
            <button class="action" id="bathButton" onclick="startBath()">START BATH</button>
        </div>
    `;
}

function startBath() {
    bathMoves = 0;
    bathActive = true;
    bathLast = null;

    const soap = document.getElementById("soap");
    document.getElementById("bathButton").disabled = true;

    soap.onpointerdown = e => {
        soap.setPointerCapture(e.pointerId);
        bathLast = {x:e.clientX, y:e.clientY};
    };

    soap.onpointermove = e => {
        if (!bathActive || !bathLast) return;

        if (Math.hypot(e.clientX - bathLast.x, e.clientY - bathLast.y) > 18) {
            bathMoves++;
            bathLast = {x:e.clientX, y:e.clientY};

            document.getElementById("bathProgress").textContent =
                Math.min(10, bathMoves) + " / 10 scrubs";

            if (bathMoves >= 10) finishBath();
        }
    };

    soap.onpointerup = () => bathLast = null;
    soap.onpointercancel = () => bathLast = null;
}

function finishBath() {
    bathActive = false;
    pet.cleanliness = 100;
    pet.happiness = clamp(pet.happiness + 8);

    addXP(8);

    document.getElementById("bathPet").textContent = "🐣✨";
    document.getElementById("bathProgress").textContent = "All clean! ✨";

    document.getElementById("bathButton").disabled = false;
    document.getElementById("bathButton").textContent = "DONE!";

    notify("Lumies is sparkling clean!");

    updateUI();
    saveGame();
}

// ===================================
// BEDROOM
// ===================================

function showBedroom() {
    document.getElementById("roomPanel").innerHTML = `
        <h3>🛏️ Cozy Bedroom</h3>
        <p class="description">Let Lumies take a nap and restore energy.</p>

        <div class="game-area" style="background:#e9e3f8">
            <div class="big-emoji" id="sleepIcon">🛏️</div>
            <p id="sleepText">Ready for a little nap?</p>
            <button class="action" id="sleepButton" onclick="toggleSleep()">🌙 Sleep</button>
        </div>
    `;
}

function toggleSleep() {
    sleeping = !sleeping;

    if (sleeping) {
        pet.energy = clamp(pet.energy + 35);
        pet.happiness = clamp(pet.happiness + 4);

        document.getElementById("sleepIcon").textContent = "💤";
        document.getElementById("sleepText").textContent = "Zzz... Sweet dreams!";
        document.getElementById("sleepButton").textContent = "☀️ Wake Up";

        notify("Lumies had a nice nap!");
    } else {
        document.getElementById("sleepIcon").textContent = "🌞";
        document.getElementById("sleepText").textContent = "Good morning!";
        document.getElementById("sleepButton").textContent = "🌙 Sleep";

        notify("Lumies is awake!");
    }

    updateUI();
    saveGame();
}

// ===================================
// GAME ROOM
// ===================================

function showGame() {
    document.getElementById("roomPanel").innerHTML = `
        <h3>🎮 Game Room</h3>
        <p class="description">Choose a mini-game! Earn coins and XP.</p>

        <div class="items">
            <button class="item" onclick="startGameMode('stars')">
                <span>⭐</span>Star Catch<br>Catch stars!
            </button>

            <button class="item" onclick="startGameMode('memory')">
                <span>🧠</span>Memory<br>Remember icons!
            </button>

            <button class="item" onclick="startGameMode('bubble')">
                <span>🫧</span>Bubble Pop<br>Pop bubbles!
            </button>
        </div>

        <div id="miniArea" class="game-area">
            <div class="big-emoji">🎮</div>
            <p>Pick a game to start playing!</p>
        </div>
    `;
}

function startGameMode(mode) {
    if (pet.energy < 8) {
        notify("Lumies needs more energy!");
        return;
    }

    gameMode = mode;
    gameScore = 0;
    miniPlaying = true;

    pet.energy = clamp(pet.energy - 8);

    updateUI();
    saveGame();

    const area = document.getElementById("miniArea");

    if (mode === "stars") {
        area.innerHTML = `
            <h3>⭐ Star Catch</h3>
            <p>Tap as many stars as you can in 12 seconds!</p>
            <h2 id="miniScore">0</h2>
            <button class="star-target" onclick="miniTap()">⭐</button>
            <p id="miniTime">12 seconds</p>
        `;

        startCountdown(12);
    }

    if (mode === "bubble") {
        area.innerHTML = `
            <h3>🫧 Bubble Pop</h3>
            <p>Pop the bubbles! Tap them quickly!</p>
            <h2 id="miniScore">0</h2>
            <div class="choice-row" id="bubbleChoices"></div>
            <p id="miniTime">12 seconds</p>
        `;

        bubbleRound();
        startCountdown(12);
    }

    if (mode === "memory") {
        const icons = ["🍓","⭐","🌸","🍎"];

        memorySequence = [
            randomItem(icons),
            randomItem(icons),
            randomItem(icons)
        ];

        memoryIndex = 0;

        area.innerHTML = `
            <h3>🧠 Memory Match</h3>
            <p>Remember this sequence:</p>

            <h1 style="font-size:35px;margin:18px">
                ${memorySequence.join(" ")}
            </h1>

            <p>Now repeat it in the correct order!</p>

            <div class="choice-row">
                ${icons.map(x => `
                    <button class="secondary" onclick="memoryTap('${x}')">${x}</button>
                `).join("")}
            </div>

            <p id="memoryFeedback"></p>
        `;
    }
}

function startCountdown(seconds) {
    let left = seconds;

    clearInterval(miniTimer);

    miniTimer = setInterval(() => {
        left--;

        const el = document.getElementById("miniTime");

        if (el) el.textContent = left + " seconds";

        if (left <= 0) endMiniGame();
    }, 1000);
}

function miniTap() {
    if (!miniPlaying || gameMode !== "stars") return;

    gameScore++;

    document.getElementById("miniScore").textContent = gameScore;

    const b = document.querySelector("#miniArea .star-target");

    b.textContent = randomItem(["⭐","🌟","✨","💫"]);
}

function bubbleRound() {
    const icons = ["🫧","🔵","🟣","💧","⚪"];

    document.getElementById("bubbleChoices").innerHTML =
        Array.from({length:6}, () => `
            <button class="secondary" style="font-size:23px"
                onclick="bubbleTap(this)">
                ${randomItem(icons)}
            </button>
        `).join("");
}

function bubbleTap(btn) {
    if (!miniPlaying || gameMode !== "bubble") return;

    gameScore++;

    document.getElementById("miniScore").textContent = gameScore;

    btn.textContent = "💥";
    btn.disabled = true;
}

function memoryTap(icon) {
    if (!miniPlaying || gameMode !== "memory") return;

    if (icon === memorySequence[memoryIndex]) {
        memoryIndex++;
        gameScore += 5;

        document.getElementById("memoryFeedback").textContent = "Correct! ✨";

        if (memoryIndex === memorySequence.length) {
            miniPlaying = false;

            pet.coins += 15;
            pet.happiness = clamp(pet.happiness + 8);

            addXP(8);

            document.getElementById("memoryFeedback").textContent =
                "Perfect memory! +15 coins!";

            saveGame();
            updateUI();
        }
    } else {
        miniPlaying = false;

        document.getElementById("memoryFeedback").textContent =
            "Oops! Try again next time.";

        pet.coins += 3;

        saveGame();
        updateUI();
    }
}

function endMiniGame() {
    clearInterval(miniTimer);

    if (!miniPlaying) return;

    miniPlaying = false;

    const reward = Math.max(3, gameScore * 2);

    pet.coins += reward;
    pet.happiness = clamp(pet.happiness + Math.min(12, gameScore));

    addXP(Math.max(2, gameScore));

    const area = document.getElementById("miniArea");

    if (area) {
        area.innerHTML = `
            <h2>🎉 Game Over!</h2>
            <p>You scored ${gameScore} points!</p>
            <div class="big-emoji">🏆</div>
            <p>Reward: ${reward} coins!</p>
            <button class="action" onclick="showGame()">Play Again</button>
        `;
    }

    notify("+" + reward + " coins!");

    updateUI();
    saveGame();
}

// ===================================
// GARDEN
// ===================================

function showGarden() {
    let plant = pet.plant >= 3 ? "🌸" :
        pet.plant === 2 ? "🌻" :
        pet.plant === 1 ? "🌱" : "🪴";

    document.getElementById("roomPanel").innerHTML = `
        <h3>🌷 Little Garden</h3>
        <p class="description">Grow flowers, remove weeds, and harvest your garden!</p>

        <div class="game-area" style="background:#e6f1dc">
            <div class="big-emoji" id="plantIcon">${plant}</div>
            <p id="plantText">Growth: ${pet.plant}/3</p>

            <div class="choice-row">
                <button class="action" onclick="waterPlant()">💧 Water</button>
                <button class="secondary" onclick="removeWeeds()">🌿 Remove weeds</button>
                <button class="secondary" onclick="harvestPlant()">🧺 Harvest</button>
            </div>

            <p id="gardenMessage" class="description"></p>
        </div>

        <div class="recipe-card">
            <p>🌱 Watering helps your plant grow.</p>
            <p>🌿 Weeds sometimes appear in the garden.</p>
            <p>🌸 Fully grown flowers can be harvested for coins!</p>
        </div>
    `;
}

function waterPlant() {
    if (pet.plant >= 3) {
        notify("Your flower is already grown!");
        return;
    }

    if (pet.watered) {
        notify("The plant has enough water for now!");
        return;
    }

    pet.watered = true;
    pet.plant++;

    document.getElementById("gardenMessage").textContent =
        "The plant is growing! 💚";

    addXP(5);
    saveGame();
    showGarden();
    updateUI();
}

function removeWeeds() {
    if (!pet.weeds) {
        pet.weeds = true;
        notify("You tidied up the garden!");
    } else {
        pet.weeds = false;
        pet.coins += 4;
        addXP(3);

        notify("Weeds removed! +4 coins");
    }

    saveGame();
    showGarden();
    updateUI();
}

function harvestPlant() {
    if (pet.plant < 3) {
        notify("Wait until your flower has grown!");
        return;
    }

    if (gardenHarvested) {
        notify("Come back later for another harvest!");
        return;
    }

    pet.coins += 20;
    pet.plant = 0;
    pet.watered = false;
    gardenHarvested = true;

    addXP(10);

    notify("Flower harvested! +20 coins");

    saveGame();
    showGarden();
    updateUI();
}

// ===================================
// WARDROBE
// ===================================

function showWardrobe() {
    let html = `
        <h3>👗 Wardrobe</h3>
        <p class="description">Customize your little buddy!</p>
        <div class="items">
    `;

    petColors.forEach(([name, color]) => {
        html += `
            <button class="item" onclick="changeColor('${color}')">
                <span style="color:${color}">●</span>
                ${name}
            </button>
        `;
    });

    html += `
        </div>
        <h3 style="margin-top:20px">🎀 Accessories</h3>
        <div class="items">
    `;

    accessories.forEach(([icon, name, cost]) => {
        html += `
            <button class="item" onclick="buyAccessory('${icon}',${cost})">
                <span>${icon}</span>
                ${name}<br>${cost} coins
            </button>
        `;
    });

    html += `
        <button class="item" onclick="wear('')">
            <span>❌</span>Remove
        </button>
        </div>
    `;

    document.getElementById("roomPanel").innerHTML = html;
}

function changeColor(color) {
    pet.color = color;
    updateUI();
    saveGame();
    notify("New color!");
}

function wear(item) {
    pet.accessory = item;
    updateUI();
    saveGame();
    notify("Accessory changed!");
}

function buyAccessory(item, cost) {
    if (pet.coins < cost) {
        notify("Not enough coins!");
        return;
    }

    pet.coins -= cost;
    pet.accessory = item;

    addXP(2);
    saveGame();
    updateUI();

    notify("New accessory unlocked!");
}

// ===================================
// SHOP
// ===================================

function showShop() {
    document.getElementById("roomPanel").innerHTML = `
        <h3>🛍️ Little Shop</h3>
        <p class="description">Buy accessories and special treats for Lumies.</p>

        <div class="items">
            <button class="item" onclick="buyAccessory('🎀',15)">
                <span>🎀</span>Ribbon<br>15 coins
            </button>

            <button class="item" onclick="buyAccessory('👑',30)">
                <span>👑</span>Crown<br>30 coins
            </button>

            <button class="item" onclick="buyAccessory('🐰',28)">
                <span>🐰</span>Bunny Ears<br>28 coins
            </button>

            <button class="item" onclick="buyAccessory('🎧',25)">
                <span>🎧</span>Headphones<br>25 coins
            </button>

            <button class="item" onclick="buyAccessory('🧸',40)">
                <span>🧸</span>Bear Hood<br>40 coins
            </button>

            <button class="item" onclick="buyAccessory('💎',35)">
                <span>💎</span>Gem<br>35 coins
            </button>
        </div>
    `;
}

// ===================================
// PROFILE
// ===================================

function showProfile() {
    document.getElementById("roomPanel").innerHTML = `
        <h3>📋 Pet Profile</h3>

        <div class="recipe-card">
            <p>🐣 Name: <b>${escapeHTML(pet.name)}</b></p>
            <p>⭐ Level: <b>${level()}</b></p>
            <p>✨ XP: <b>${pet.xp % 50}/50 to next level</b></p>
            <p>🪙 Coins: <b>${pet.coins}</b></p>
            <p>🌷 Garden growth: <b>${pet.plant}/3</b></p>
        </div>

        <button class="secondary" onclick="renamePet()">✏️ Change Name</button>
        <button class="secondary" onclick="resetGame()">🔄 Reset Game</button>
    `;
}

function escapeHTML(s) {
    return String(s).replace(/[&<>"']/g, c => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    }[c]));
}

function renamePet() {
    const name = prompt("What would you like to name your pet?", pet.name);

    if (name && name.trim()) {
        pet.name = name.trim().slice(0, 15);

        updateUI();
        showProfile();
        saveGame();
    }
}

function resetGame() {
    if (!confirm("Start a new game? Your progress will be lost.")) return;

    localStorage.removeItem("littleBuddySave");

    pet = {...defaultState, lastTime:Date.now()};
    gardenHarvested = false;

    updateUI();
    goRoom("home", document.querySelector(".nav button"));

    notify("A new adventure begins!");
}

// ===================================
// STATUS DECAY
// ===================================

function applyOffline() {
    const now = Date.now();

    const elapsed = Math.min(
        Math.max(0, (now - (pet.lastTime || now)) / 1000),
        28800
    );

    const periods = elapsed / 3600;

    pet.hunger = clamp(pet.hunger - periods * 1.5);
    pet.happiness = clamp(pet.happiness - periods * 0.8);
    pet.cleanliness = clamp(pet.cleanliness - periods * 0.7);
    pet.energy = clamp(pet.energy - periods * 1);

    pet.lastTime = now;
}

applyOffline();
updateUI();
saveGame();

setInterval(() => {
    if (!sleeping) {
        pet.hunger = clamp(pet.hunger - 0.12);
        pet.happiness = clamp(pet.happiness - 0.08);
        pet.cleanliness = clamp(pet.cleanliness - 0.06);
        pet.energy = clamp(pet.energy - 0.08);
    }

    updateUI();
    saveGame();
}, 60000);

setInterval(() => {
    if (Math.random() < 0.12) {
        pet.weeds = true;
    }
}, 120000);

// ===================================
// START GAME
// ===================================

showHome();

