
// DATA AWAL PET
const defaultState = {
    name: "Lumies",
    coins: 50,
    xp: 0,
    hunger: 80,
    happiness: 80,
    cleanliness: 80,
    energy: 80,
    color: "#f4b5a0",
    accessory: "",
    plant: 0,
    watered: false,
    weeds: false,
    lastTime: Date.now()
};

// DATA MAKANAN
const foods = [
    {name:"Apple",icon:"🍎",cost:0,hunger:10,happy:3},
    {name:"Carrot",icon:"🥕",cost:0,hunger:8,happy:2},
    {name:"Strawberry",icon:"🍓",cost:5,hunger:14,happy:8},
    {name:"Watermelon",icon:"🍉",cost:8,hunger:20,happy:8},
    {name:"Cake",icon:"🍰",cost:10,hunger:20,happy:12},
    {name:"Pizza",icon:"🍕",cost:10,hunger:25,happy:10},
    {name:"Cookie",icon:"🍪",cost:7,hunger:12,happy:10},
    {name:"Milk",icon:"🥛",cost:6,hunger:12,happy:5},
    {name:"Donut",icon:"🍩",cost:12,hunger:18,happy:15},
    {name:"Sushi",icon:"🍣",cost:15,hunger:28,happy:12},
    {name:"Ice Cream",icon:"🍦",cost:12,hunger:15,happy:20},
    {name:"Sandwich",icon:"🥪",cost:9,hunger:22,happy:7}
];

// DATA AKSESORI
const accessories = [
    ["🎀","Ribbon",15],
    ["👑","Crown",30],
    ["🌸","Flower",12],
    ["🧢","Cap",20],
    ["🕶️","Glasses",22],
    ["🎩","Top Hat",25],
    ["🧣","Scarf",18],
    ["🐰","Bunny Ears",28],
    ["⭐","Star Clip",15],
    ["🦋","Butterfly",20],
    ["👒","Sun Hat",25],
    ["💎","Gem",35],
    ["🧸","Bear Hood",40],
    ["🌈","Rainbow",30],
    ["🎧","Headphones",25]
];

// DATA WARNA PET
const petColors = [
    ["Peach","#f4b5a0"],
    ["Pink","#f5a4c1"],
    ["Yellow","#f6d77c"],
    ["Mint","#a6d9c4"],
    ["Purple","#c3afe8"],
    ["Blue","#9fc9eb"],
    ["Cream","#f2dfb7"],
    ["Lavender","#d8c2ee"]
];

// DATA RESPONS CHAT
const chatReplies = {
    greeting: [
        "Hiiii! 💗",
        "Hellooo! I missed you!",
        "Hey! Let's play!"
    ],
    love: [
        "I love you too! 💗",
        "Awww, you're so sweet!",
        "You're my best friend! 🥹"
    ],
    joke: [
        "Why did the tomato blush? Because it saw the salad dressing! 🍅😂",
        "What do you call a sleeping dinosaur? A dino-snore! 🦖",
        "Why did the cookie go to the doctor? Because it felt crummy! 🍪"
    ],
    general: [
        "Really? Tell me more! 👀",
        "Ooh, that's interesting!",
        "Hehe, I like talking with you! 💗",
        "What happened next?",
        "I see! Let's talk more!",
        "You're fun to chat with!",
        "Hmm... I need a little time to think about that. 🐣"
      
    ]
};

